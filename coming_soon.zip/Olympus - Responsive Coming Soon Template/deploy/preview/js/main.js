(function($) {
    
    "use strict";
    
    //Window load
    $(window).on("load", function() {     
        //Hide prage loader
        $(".page-loader").fadeOut();
    });
    
})(jQuery);